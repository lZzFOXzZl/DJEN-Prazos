// DJEN Prazos v6.0 — Fox Diamond
// Motor de prazos processuais: CPC/2015, CLT, CPP

// ══════════════════════════════════════
// FERIADOS
// ══════════════════════════════════════
const FIXOS_NAC = ["01-01","21-04","01-05","07-09","12-10","02-11","15-11","20-11","25-12"];

// Cache de feriados estaduais vindos da BrasilAPI
const _feriadosCache = {}; // { "2026-CE": ["2026-03-19", ...] }

async function carregarFeriadosEstado(ano, uf) {
  const key = `${ano}-${uf}`;
  if (_feriadosCache[key]) return _feriadosCache[key];
  try {
    const r = await fetch(`https://brasilapi.com.br/api/feriados/v1/${ano}`);
    if (!r.ok) return [];
    const lista = await r.json();
    // BrasilAPI retorna nacionais; filtra os que têm type !== "national" ou name inclui estado
    // Guarda todos para o ano
    const datas = lista.map(f => f.date); // "2026-03-19"
    _feriadosCache[key] = datas;
    return datas;
  } catch(_) { return []; }
}

function isFeriadoAPI(isoDate, feriadosLista) {
  return feriadosLista.includes(isoDate);
}

function pascoa(ano) {
  const a=ano%19,b=Math.floor(ano/100),c=ano%100,d=Math.floor(b/4),e=b%4,
        f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),
        h=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4,
        l=(32+2*e+2*i-h-k)%7,m=Math.floor((a+11*h+22*l)/451),
        mes=Math.floor((h+l-7*m+114)/31),dia=((h+l-7*m+114)%31)+1;
  return new Date(ano,mes-1,dia);
}
function feriadosMoveis(ano) {
  const P=pascoa(ano), add=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x;};
  return [add(P,-48),add(P,-47),add(P,-2),P,add(P,60)];
}
function isFeriado(d, incFor=false, feriadosExtra=[]) {
  const ch=`${String(d.getDate()).padStart(2,'0')}-${String(d.getMonth()+1).padStart(2,'0')}`;
  if (FIXOS_NAC.includes(ch)) return { sim: true, nome: nomeFeriadoNac(ch) };
  const mov = feriadosMoveis(d.getFullYear());
  const nomes = ['Segunda de Carnaval','Terça de Carnaval','Sexta-feira Santa','Páscoa','Corpus Christi'];
  for (let i=0;i<mov.length;i++) {
    if (mov[i].toDateString()===d.toDateString()) return { sim: true, nome: nomes[i] };
  }
  // Feriados estaduais/municipais da API
  const iso = d.toISOString().split('T')[0];
  if (feriadosExtra.includes(iso)) return { sim: true, nome: 'Feriado estadual/municipal' };
  return { sim: false };
}
function nomeFeriadoNac(ch) {
  const m = {"01-01":"Confraternização Universal","21-04":"Tiradentes","01-05":"Dia do Trabalho",
    "07-09":"Independência","12-10":"N. Sra. Aparecida","02-11":"Finados",
    "15-11":"Proclamação da República","20-11":"Consciência Negra","25-12":"Natal"};
  return m[ch] || 'Feriado nacional';
}
function isUtil(d, incFor=false, feriadosExtra=[]) {
  return d.getDay()!==0 && d.getDay()!==6 && !isFeriado(d, incFor, feriadosExtra).sim;
}

// ══════════════════════════════════════
// RECESSO FORENSE — art. 220 CPC
// ══════════════════════════════════════
function isRecessoCPC(d) {
  const mes=d.getMonth()+1, dia=d.getDate();
  return (mes===12 && dia>=20) || (mes===1 && dia<=20);
}

// ══════════════════════════════════════
// MOTORES DE CÁLCULO POR MATÉRIA
// ══════════════════════════════════════

// CÍVEL / FEDERAL — CPC/2015 (arts. 219, 220, 231)
// CPC/2015 arts. 219, 220, 231 — exclui dia da pub; 1º dia útil fora do recesso = dia 1
function calcCivel(isoPublicacao, prazo, incFor=false, fe=[]) {
  let d = new Date(isoPublicacao + "T12:00:00");
  d.setDate(d.getDate()+1);
  while (!isUtil(d,incFor,fe) || isRecessoCPC(d)) d.setDate(d.getDate()+1);
  const inicio = new Date(d);
  let c=1;
  while (c<prazo) { d.setDate(d.getDate()+1); if(isUtil(d,incFor,fe) && !isRecessoCPC(d)) c++; }
  while (!isUtil(d,incFor,fe) || isRecessoCPC(d)) d.setDate(d.getDate()+1);
  return { venc:d, inicio };
}

// TRABALHISTA — CLT art. 775 (dias úteis, sem recesso CPC)
// CLT art. 775 — exclui dia do começo; 1º dia útil fora do recesso = dia 1
// Recesso 20/dez–20/jan também se aplica à Justiça do Trabalho
function calcTrabalhista(isoPublicacao, prazo, incFor=false, fe=[]) {
  let d = new Date(isoPublicacao + "T12:00:00");
  d.setDate(d.getDate()+1);
  while (!isUtil(d,incFor) || isRecessoCPC(d)) d.setDate(d.getDate()+1);
  const inicio = new Date(d);
  let c=1; // inicio já é o dia 1
  while (c<prazo) { d.setDate(d.getDate()+1); if(isUtil(d,incFor) && !isRecessoCPC(d)) c++; }
  while (!isUtil(d,incFor) || isRecessoCPC(d)) d.setDate(d.getDate()+1);
  return { venc:d, inicio };
}

// PENAL — CPP arts. 798-800 (corrido; prorroga se cair em não-útil)
function calcPenal(isoPublicacao, prazo, fe=[]) {
  let d = new Date(isoPublicacao + "T12:00:00");
  d.setDate(d.getDate()+1);
  const inicio = new Date(d);
  d.setDate(d.getDate() + prazo - 1);
  while (!isUtil(d,false,fe)) d.setDate(d.getDate()+1);
  return { venc:d, inicio };
}

function calcVencimento(materia, isoPublicacao, prazo, incFor=false, fe=[]) {
  switch(materia){
    case 'trabalhista': return calcTrabalhista(isoPublicacao, prazo, incFor, fe);
    case 'penal':       return calcPenal(isoPublicacao, prazo, fe);
    default:            return calcCivel(isoPublicacao, prazo, incFor, fe);
  }
}

// ══════════════════════════════════════
// UTILITÁRIOS
// ══════════════════════════════════════
function diasUteisAte(venc, incFor=false) {
  const hoje=new Date(); hoje.setHours(0,0,0,0);
  const fim=new Date(venc); fim.setHours(0,0,0,0);
  if(fim<hoje) return -1;
  if(fim.toDateString()===hoje.toDateString()) return 0;
  let c=0,cur=new Date(hoje); cur.setDate(cur.getDate()+1);
  while(cur<=fim){if(isUtil(cur,incFor))c++;cur.setDate(cur.getDate()+1);}
  return c;
}
function feriadosNoPeriodo(inicio, fim, incFor=false) {
  const lista=[]; let cur=new Date(inicio); cur.setDate(cur.getDate()+1);
  while(cur<=fim){
    const f=isFeriado(cur,incFor);
    if(f.sim && cur.getDay()!==0 && cur.getDay()!==6)
      lista.push(`${fmtData(cur.toISOString().split('T')[0])} (${f.nome})`);
    cur.setDate(cur.getDate()+1);
  }
  return lista;
}
function recessoDiasNoPeriodo(inicio, fim) {
  let n=0, cur=new Date(inicio); cur.setDate(cur.getDate()+1);
  while(cur<=fim){ if(isRecessoCPC(cur) && isUtil(cur)) n++; cur.setDate(cur.getDate()+1); }
  return n;
}
function fmtData(iso) {
  if(!iso) return "—";
  const d=new Date(iso+"T12:00:00");
  return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
}
function limparHtml(html) {
  if(!html) return "";
  try { const doc=new DOMParser().parseFromString(html,'text/html'); return (doc.body.textContent||"").replace(/\s\s+/g,' ').trim(); }
  catch(_){ return html.replace(/<[^>]*>/g,'').trim(); }
}

// ══════════════════════════════════════
// DOM REFS
// ══════════════════════════════════════
const $ = id => document.getElementById(id);
const headerAdv=$('headerAdv'),tabInt=$('tabInt'),tabCalc=$('tabCalc'),tabApoio=$('tabApoio');
const panelInt=$('panelInt'),panelCalc=$('panelCalc'),panelApoio=$('panelApoio');
const oabNum=$('oabNum'),oabUf=$('oabUf'),dataIni=$('dataIni'),dataFim=$('dataFim');
const btnBuscar=$('btnBuscar'),toolbar=$('toolbar'),tbInfo=$('tbInfo');
const btnCopiar=$('btnCopiar'),btnTxt=$('btnTxt'),filterRow=$('filterRow');
const filtroTrib=$('filtroTrib'),filtroKw=$('filtroKw'),stateArea=$('stateArea'),resultsEl=$('results');
const calcOrigem=$('calcOrigem'),calcOrigemClose=$('calcOrigemClose');
const calcEstado=$('calcEstado'),calcMateria=$('calcMateria'),calcTribunal=$('calcTribunal');
const calcDataPub=$('calcDataPub'),calcDias=$('calcDias');
const ctUteis=$('ctUteis'),ctCorridos=$('ctCorridos');
const feriadosInfo=$('feriadosInfo'),feriadosInfoTxt=$('feriadosInfoTxt'),btnCalcular=$('btnCalcular');
const calcResultado=$('calcResultado'),crDate=$('crDate'),crPub=$('crPub'),crInicio=$('crInicio');
const crPrazo=$('crPrazo'),crRestantes=$('crRestantes'),crAviso=$('crAviso'),crFeriados=$('crFeriados');
const historicoWrap=$('historicoWrap'),historicoLista=$('historicoLista'),histClear=$('histClear');
const overlay=$('modalOverlay'),mStripe=$('mStripe'),mBadges=$('mBadges'),mProc=$('mProc');
const mDispEl=$('mDisp'),mTexto=$('mTexto'),iaSpinner=$('iaSpinner');
const prazoAlert=$('prazoAlert'),paBody=$('paBody'),btnCalcPrazo=$('btnCalcPrazo');
const modalClose=$('modalClose'),mBtnFechar=$('mBtnFechar'),mBtnCopiar=$('mBtnCopiar');

let processados=[],filtrados=[],itemAtual=null;

// ══════════════════════════════════════
// ABAS
// ══════════════════════════════════════
[tabInt,tabCalc,tabApoio].forEach(tab=>{
  tab.addEventListener('click',()=>{
    [tabInt,tabCalc,tabApoio].forEach(t=>t.classList.remove('active'));
    [panelInt,panelCalc,panelApoio].forEach(p=>p.classList.remove('active'));
    tab.classList.add('active'); $(tab.dataset.panel).classList.add('active');
  });
});
$('btnCopiarPix').addEventListener('click',()=>{
  const chave=$('pixChave').textContent.trim();
  navigator.clipboard.writeText(chave).then(()=>{
    const btn=$('btnCopiarPix'); btn.textContent='✅ Copiado!'; btn.classList.add('copiado');
    setTimeout(()=>{btn.textContent='📋 Copiar';btn.classList.remove('copiado');},2000);
  });
});

// ══════════════════════════════════════
// PREFS / DATAS
// ══════════════════════════════════════
function salvar(){try{localStorage.setItem('djen_oab',oabNum.value);localStorage.setItem('djen_uf',oabUf.value);}catch(_){}}
function carregar(){
  try{
    oabNum.value=localStorage.getItem('djen_oab')||'';
    oabUf.value=localStorage.getItem('djen_uf')||'CE';
    const nome=localStorage.getItem('djen_nome_'+(oabNum.value||'')+'_'+(oabUf.value||''));
    if(nome){headerAdv.textContent=nome;headerAdv.className='header-adv';}
  }catch(_){}
}
const isoHoje=()=>new Date().toISOString().split('T')[0];
function isoMenos(dias){const d=new Date();d.setDate(d.getDate()-dias);return d.toISOString().split('T')[0];}
function setDatas(dias){dataIni.value=isoMenos(dias);dataFim.value=isoHoje();}
setDatas(5); carregar(); calcDataPub.value=isoHoje();

// ══════════════════════════════════════
// NOME DO ADVOGADO
// ══════════════════════════════════════
async function buscarNomeAdv(num,uf){
  try{const r=await fetch(`https://comunicaapi.pje.jus.br/api/v1/advogado?numeroOab=${encodeURIComponent(num)}&ufOab=${encodeURIComponent(uf)}`);
    if(r.ok){const d=await r.json();const n=d.nome||d.nomeAdvogado||(d.items&&d.items[0]&&d.items[0].nome);if(n)return n;}}catch(_){}
  try{const r2=await fetch(`https://comunicaapi.pje.jus.br/api/v1/comunicacao?numeroOab=${encodeURIComponent(num)}&ufOab=${encodeURIComponent(uf)}&dataDisponibilizacaoInicio=${isoMenos(90)}&dataDisponibilizacaoFim=${isoHoje()}`);
    if(r2.ok){const d2=await r2.json();for(const i of(d2.items||[])){const n=i.nomeAdvogado||i.nome_advogado||i.advogado;if(n)return n;}}}catch(_){}
  return null;
}
async function atualizarNomeAdv(){
  const num=oabNum.value.trim(),uf=oabUf.value.trim().toUpperCase();
  if(!num||!uf||uf.length<2){headerAdv.textContent="—";return;}
  headerAdv.textContent="buscando..."; headerAdv.className="header-adv loading";
  const nome=await buscarNomeAdv(num,uf);
  if(nome){headerAdv.textContent=nome;headerAdv.className="header-adv";try{localStorage.setItem('djen_nome_'+num+'_'+uf,nome);}catch(_){}}
  else{const cache=localStorage.getItem('djen_nome_'+num+'_'+uf);headerAdv.textContent=cache||(num+'/'+uf);headerAdv.className="header-adv";}
}
oabNum.addEventListener('blur',atualizarNomeAdv);
oabUf.addEventListener('blur',atualizarNomeAdv);
document.querySelectorAll('.qb').forEach(b=>{b.addEventListener('click',()=>{setDatas(parseInt(b.dataset.d));btnBuscar.click();});});
oabNum.addEventListener('keydown',e=>{if(e.key==='Enter')btnBuscar.click();});
oabUf.addEventListener('keydown',e=>{if(e.key==='Enter')btnBuscar.click();});

// ══════════════════════════════════════
// ANÁLISE LOCAL DE PRAZOS
// ══════════════════════════════════════
const PRAZO_RES=[
  /(?:no\s+)?prazo\s+de\s+\d+\s*(?:\([^)]+\)\s*)?(?:dias?|horas?|h)\s*(?:[úu]teis?|corridos?)?[^.!?\n]{0,80}/gi,
  /em\s+\d+\s*(?:\([^)]+\)\s*)?(?:dias?|horas?)[^.!?\n]{0,60}/gi,
  /dentro\s+de\s+\d+\s*(?:dias?|horas?)[^.!?\n]{0,60}/gi,
  /at[ée]\s+\d+\s*(?:dias?|horas?)[^.!?\n]{0,60}/gi,
  /comparecer[^.!?\n]{0,20}prazo[^.!?\n]{0,60}/gi,
  /manifestar[^.!?\n]{0,20}prazo[^.!?\n]{0,60}/gi,
  /apresentar[^.!?\n]{0,20}prazo[^.!?\n]{0,60}/gi,
  /entregar[^.!?\n]{0,30}prazo[^.!?\n]{0,60}/gi,
];
const PRAZO_DIAS_RE=/(\d+)\s*(?:\([^)]+\)\s*)?(?:dias?)/i;
function analisarPrazos(txt){
  const enc=new Set(),res=[];
  for(const re of PRAZO_RES){let m;while((m=re.exec(txt))!==null){const t=m[0].trim().replace(/\s+/g,' ');const ch=t.slice(0,40).toLowerCase();if(!enc.has(ch)){enc.add(ch);res.push(t);}}}
  return res;
}
function extrairDiasDeTrechos(trechos){for(const t of trechos){const m=t.match(PRAZO_DIAS_RE);if(m)return parseInt(m[1],10);}return null;}

// ══════════════════════════════════════
// ANÁLISE VIA IA
// ══════════════════════════════════════
async function analisarIA(txt){
  try{
    const resp=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,
        system:`Você é um assistente jurídico especializado em direito processual brasileiro.\nAnalise a publicação judicial e identifique prazos que a parte intimada deve cumprir.\nResponda APENAS em JSON válido sem markdown:\n{"prazos":[{"trecho":"texto exato","acao":"o que fazer","dias":5,"tipo":"úteis"}]}\nSe não houver prazo, retorne: {"prazos":[]}`,
        messages:[{role:"user",content:`Publicação:\n\n${txt.slice(0,3000)}`}]})});
    if(!resp.ok) return null;
    const data=await resp.json();
    const raw=(data.content||[]).map(c=>c.text||"").join("");
    return JSON.parse(raw.replace(/```json|```/g,"").trim()).prazos||[];
  }catch(_){return null;}
}

// ══════════════════════════════════════
// PROCESSAR / LISTA / MODAL
// ══════════════════════════════════════
function processar(items){
  return items.map(item=>{
    const txt=limparHtml(item.texto||item.teor||"");
    const mP=txt.match(/\d{7}-\d{2}\.\d{4}\.\d{1,2}\.\d{2}\.\d{4}/);
    const processo=item.numeroProcesso||item.numeroprocesso||(mP?mP[0]:"");
    const tribunal=item.siglaTribunal||item.sigla_tribunal||"—";
    const dataRaw=item.dataDisponibilizacao||item.data_disponibilizacao||"";
    const dataISO=dataRaw?dataRaw.split("T")[0]:"";
    const prazosLocais=analisarPrazos(txt);
    return {txt,processo,tribunal,dataISO,temPrazo:prazosLocais.length>0,prazosLocais};
  });
}
function renderLinha(p){
  const div=document.createElement('div');
  div.className=`list-item ${p.temPrazo?'tem-prazo':'sem-prazo'}`;
  const prazoBadge=p.temPrazo?`<span class="badge b-prazo">⚠ Prazo</span>`:'';
  const resumo=p.txt.slice(0,100).replace(/\n/g,' ');
  div.innerHTML=`<div class="prazo-icon ${p.temPrazo?'tem-prazo':'sem-prazo'}">${p.temPrazo?'⚠️':'📄'}</div>
    <div class="list-info"><div class="list-top"><span class="badge b-trib">${p.tribunal}</span>${prazoBadge}
    <span class="list-data">Disp: ${fmtData(p.dataISO)}</span></div>
    ${p.processo?`<div class="list-proc">${p.processo}</div>`:''}
    <div class="list-resumo">${resumo||'(sem texto)'}</div></div><span class="list-arrow">›</span>`;
  div.addEventListener('click',()=>abrirModal(p)); return div;
}
function renderLista(lista){
  resultsEl.innerHTML='';
  if(lista.length===0){resultsEl.innerHTML=`<div class="state"><div class="state-icon">🔎</div><div>Nenhum resultado.</div></div>`;return;}
  lista.forEach(p=>resultsEl.appendChild(renderLinha(p)));
}
function destacarPrazos(txt,trechos){
  let e=txt.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  for(const t of trechos){const et=t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    try{e=e.replace(new RegExp(et.slice(0,60),'gi'),m=>`<mark class="prazo-highlight">${m}</mark>`);}catch(_){}}
  return e;
}
async function abrirModal(p){
  itemAtual=p;
  mStripe.className=`modal-stripe ${p.temPrazo?'tem-prazo':'sem-prazo'}`;
  mBadges.innerHTML=`<span class="badge b-trib">${p.tribunal}</span>${p.temPrazo?'<span class="badge b-prazo">⚠ Prazo identificado</span>':''}`;
  mProc.textContent=p.processo||''; mDispEl.textContent=p.dataISO?`Disponibilizado em: ${fmtData(p.dataISO)}`:'';
  mTexto.innerHTML=destacarPrazos(p.txt,p.prazosLocais);
  prazoAlert.classList.remove('vis'); paBody.innerHTML=''; iaSpinner.classList.remove('vis'); btnCalcPrazo.classList.remove('vis');
  overlay.classList.add('open');
  if(p.temPrazo||p.txt.toLowerCase().includes('prazo')){
    iaSpinner.classList.add('vis');
    let prazos=await analisarIA(p.txt);
    if(!prazos||prazos.length===0) prazos=p.prazosLocais.map(t=>({trecho:t,acao:'',dias:extrairDiasDeTrechos([t]),tipo:'úteis'}));
    iaSpinner.classList.remove('vis');
    if(prazos.length>0){
      paBody.innerHTML='';
      prazos.forEach(item=>{const d=document.createElement('div');d.className='pa-item';
        d.innerHTML=item.acao?`<strong>${item.acao}</strong>${item.dias?` · <span style="color:var(--gold);font-weight:700">${item.dias} ${item.tipo||'dias'}</span>`:''}<br><span style="color:var(--muted);font-size:10px">"${item.trecho}"</span>`:`"${item.trecho}"`;
        paBody.appendChild(d);});
      prazoAlert.classList.add('vis'); btnCalcPrazo.classList.add('vis');
      const diasParaCalc=prazos[0]?.dias||extrairDiasDeTrechos(p.prazosLocais)||15;
      btnCalcPrazo.onclick=()=>{fecharModal();irParaCalculadora({dataISO:p.dataISO,dias:diasParaCalc,tribunal:p.tribunal,processo:p.processo});};
    }
  }
}
function fecharModal(){overlay.classList.remove('open');iaSpinner.classList.remove('vis');itemAtual=null;}
modalClose.addEventListener('click',fecharModal); mBtnFechar.addEventListener('click',fecharModal);
overlay.addEventListener('click',e=>{if(e.target===overlay)fecharModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape')fecharModal();});
mBtnCopiar.addEventListener('click',()=>{if(!itemAtual)return;navigator.clipboard.writeText(itemAtual.txt).then(()=>{const o=mBtnCopiar.textContent;mBtnCopiar.textContent='✓ Copiado!';setTimeout(()=>mBtnCopiar.textContent=o,2000);});});

// ══════════════════════════════════════
// CALCULADORA — UI INTELIGENTE POR MATÉRIA
// ══════════════════════════════════════
function sincronizarMateriaUI(){
  const mat=calcMateria.value;
  // Sempre desabilita toggle manual — a matéria define o modo
  ctUteis.disabled=true; ctCorridos.disabled=true;
  if(mat==='penal'){
    ctUteis.classList.remove('on'); ctCorridos.classList.add('on');
    feriadosInfoTxt.textContent='⚠ Verifique feriados locais do tribunal. Feriados estaduais são carregados automaticamente.';
  } else if(mat==='trabalhista'){
    ctUteis.classList.add('on'); ctCorridos.classList.remove('on');
    feriadosInfoTxt.textContent='⚠ Feriados estaduais carregados automaticamente. Verifique feriados locais do tribunal.';
  } else {
    ctUteis.classList.add('on'); ctCorridos.classList.remove('on');
    feriadosInfoTxt.textContent='⚠ Feriados estaduais carregados automaticamente. Verifique feriados locais do tribunal.';
  }
}
calcMateria.addEventListener('change',sincronizarMateriaUI);
calcEstado.addEventListener('change',sincronizarMateriaUI);
sincronizarMateriaUI();

function irParaCalculadora({dataISO,dias,tribunal,processo}){
  tabInt.classList.remove('active'); panelInt.classList.remove('active');
  tabCalc.classList.add('active'); panelCalc.classList.add('active');
  if(dataISO) calcDataPub.value=dataISO;
  if(dias) calcDias.value=dias;
  if(tribunal){for(const opt of calcTribunal.options){if(opt.value===tribunal||opt.textContent.includes(tribunal)){calcTribunal.value=opt.value;break;}}}
  if(tribunal){
    const t=tribunal.toUpperCase();
    if(t.includes('TRT')) calcMateria.value='trabalhista';
    else if(t.includes('TRF')) calcMateria.value='federal';
    else calcMateria.value='civel';
    sincronizarMateriaUI();
  }
  calcOrigem.classList.add('vis');
  calcOrigem.querySelector('span').textContent=`⚡ Pré-preenchido${processo?' · '+processo.slice(0,25):''}`;
  panelCalc.scrollTop=0; setTimeout(()=>btnCalcular.click(),100);
}
calcOrigemClose.addEventListener('click',()=>{calcOrigem.classList.remove('vis');});

// BOTÃO CALCULAR
btnCalcular.addEventListener('click',async()=>{
  const iso=calcDataPub.value, dias=parseInt(calcDias.value)||15;
  const materia=calcMateria.value, incFor=calcEstado.value==='CE';
  if(!iso){alert('Informe a data da publicação.');return;}

  // Buscar feriados estaduais/municipais da BrasilAPI
  const anoPubl = iso.slice(0,4);
  const uf = calcEstado.value;
  const fe = await carregarFeriadosEstado(anoPubl, uf);
  const {venc,inicio}=calcVencimento(materia,iso,dias,incFor,fe);
  const restantes=diasUteisAte(venc,incFor);
  const hoje=new Date(); hoje.setHours(0,0,0,0);
  const vencD=new Date(venc); vencD.setHours(0,0,0,0);

  const labelTipo=materia==='penal'?'dias corridos (CPP)'
    :materia==='trabalhista'?'dias úteis (CLT)'
    :'dias úteis (CPC)';

  crDate.textContent=fmtData(venc.toISOString().split('T')[0]);
  crPub.textContent=fmtData(iso);
  crInicio.textContent=fmtData(inicio.toISOString().split('T')[0]);
  crPrazo.textContent=`${dias} ${labelTipo}`;
  crRestantes.textContent=restantes<0?'VENCIDO':restantes===0?'Vence hoje!':`${restantes} dias úteis`;
  crRestantes.style.color=restantes<0?'var(--red)':restantes<=3?'var(--red)':restantes<=7?'var(--gold)':'var(--green)';

  // Avisos
  crAviso.classList.remove('vis'); crAviso.textContent='';
  const avisos=[];
  if(vencD<hoje){ avisos.push('⚠ Este prazo já está vencido.'); }
  else {
    const amanha=new Date(vencD); amanha.setDate(amanha.getDate()+1);
    const fAmanha=isFeriado(amanha,incFor);
    if(fAmanha.sim) avisos.push(`ℹ Dia seguinte ao vencimento é feriado: ${fAmanha.nome}.`);
  }
  if(avisos.length>0){crAviso.textContent=avisos.join(' ');crAviso.classList.add('vis');}

  // Feriados e recesso no período
  crFeriados.classList.remove('vis'); crFeriados.innerHTML='';
  const linhas=[];
  if(materia!=='penal'){
    const fPeriodo=feriadosNoPeriodo(new Date(iso+"T12:00:00"),venc,incFor);
    if(fPeriodo.length>0) linhas.push(`📅 Feriados: ${fPeriodo.join(' · ')}`);
    if(materia==='civel'||materia==='federal'){
      const nRec=recessoDiasNoPeriodo(new Date(iso+"T12:00:00"),venc);
      if(nRec>0) linhas.push(`🏛 Recesso forense: ${nRec} dia(s) útil(eis) suspenso(s) — art. 220 CPC`);
    }
  } else {
    linhas.push('⚠ Verifique feriados locais do tribunal.');
  }
  if(linhas.length>0){crFeriados.innerHTML=linhas.join('<br>');crFeriados.classList.add('vis');}

  calcResultado.classList.add('vis');
  salvarHistorico({dataISO:iso,dias,materia,labelTipo,tribunal:calcTribunal.value,venc:venc.toISOString().split('T')[0],restantes});
  renderHistorico();
});

// ══════════════════════════════════════
// HISTÓRICO
// ══════════════════════════════════════
function salvarHistorico(item){try{let h=JSON.parse(localStorage.getItem('djen_hist')||'[]');h.unshift(item);if(h.length>5)h=h.slice(0,5);localStorage.setItem('djen_hist',JSON.stringify(h));}catch(_){}}
function carregarHistorico(){try{return JSON.parse(localStorage.getItem('djen_hist')||'[]');}catch(_){return[];}}
function renderHistorico(){
  const hist=carregarHistorico();
  if(hist.length===0){historicoWrap.style.display='none';return;}
  historicoWrap.style.display='flex'; historicoLista.innerHTML='';
  hist.forEach(h=>{
    const div=document.createElement('div'); div.className='hist-item';
    div.innerHTML=`<div class="hist-left"><span class="hist-pub">Pub: ${fmtData(h.dataISO)} · ${h.tribunal}</span><span class="hist-prazo">${h.dias}d ${h.labelTipo||''}</span></div><span class="hist-venc">${fmtData(h.venc)}</span>`;
    div.addEventListener('click',()=>{
      calcDataPub.value=h.dataISO; calcDias.value=h.dias;
      if(h.materia){calcMateria.value=h.materia;sincronizarMateriaUI();}
      for(const opt of calcTribunal.options){if(opt.value===h.tribunal){calcTribunal.value=h.tribunal;break;}}
      setTimeout(()=>btnCalcular.click(),50);
    });
    historicoLista.appendChild(div);
  });
}
histClear.addEventListener('click',()=>{try{localStorage.removeItem('djen_hist');}catch(_){}historicoWrap.style.display='none';});
renderHistorico();

// ══════════════════════════════════════
// FILTROS / EXPORTAR / BUSCA PRINCIPAL
// ══════════════════════════════════════
function aplicarFiltros(){
  const kw=filtroKw.value.toLowerCase(),tri=filtroTrib.value;
  filtrados=processados.filter(p=>(!tri||p.tribunal===tri)&&(!kw||p.txt.toLowerCase().includes(kw)||p.processo.toLowerCase().includes(kw)));
  renderLista(filtrados); atualizarToolbar();
}
filtroKw.addEventListener('input',aplicarFiltros);
filtroTrib.addEventListener('change',aplicarFiltros);
function popularTribunais(){
  const tribs=[...new Set(processados.map(p=>p.tribunal))].sort();
  filtroTrib.innerHTML='<option value="">🏛 Todos os Tribunais</option>';
  tribs.forEach(t=>{const o=document.createElement('option');o.value=o.textContent=t;filtroTrib.appendChild(o);});
}
function atualizarToolbar(){
  const cp=filtrados.filter(p=>p.temPrazo).length;
  tbInfo.innerHTML=`<strong>${filtrados.length}</strong> publicações`+(cp?` · <span style="color:var(--gold)">⚠ ${cp} com prazo</span>`:'');
}
function gerarTexto(){
  return filtrados.map(p=>[`Processo : ${p.processo||'—'}`,`Tribunal : ${p.tribunal}`,`Disp.    : ${fmtData(p.dataISO)}`,`Prazo    : ${p.temPrazo?'SIM — '+p.prazosLocais[0]:'Não identificado'}`,`Texto    : ${p.txt.slice(0,400)}`,'─'.repeat(60)].join('\n')).join('\n\n');
}
btnCopiar.addEventListener('click',()=>{const t=gerarTexto();if(!t)return;navigator.clipboard.writeText(t).then(()=>{const o=btnCopiar.textContent;btnCopiar.textContent='✓ Copiado!';setTimeout(()=>btnCopiar.textContent=o,2000);});});
btnTxt.addEventListener('click',()=>{const t=gerarTexto();if(!t)return;const blob=new Blob([t],{type:'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`Intimacoes_OAB_${oabNum.value}_${oabUf.value}_${isoHoje()}.txt`;document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);});

btnBuscar.addEventListener('click',async()=>{
  const num=oabNum.value.trim(),uf=oabUf.value.trim().toUpperCase();
  if(!num||!uf){alert('Preencha o número da OAB e a UF.');return;}
  if(!dataIni.value||!dataFim.value){alert('Informe o período de consulta.');return;}
  salvar(); btnBuscar.disabled=true; btnBuscar.textContent='⏳ Consultando...';
  resultsEl.innerHTML=''; toolbar.classList.remove('vis'); filterRow.classList.remove('vis');
  stateArea.style.display='flex'; stateArea.innerHTML='<div class="spinner"></div><div>Consultando API do CNJ...</div>';
  atualizarNomeAdv();
  try{
    const url=`https://comunicaapi.pje.jus.br/api/v1/comunicacao?numeroOab=${encodeURIComponent(num)}&ufOab=${encodeURIComponent(uf)}&dataDisponibilizacaoInicio=${dataIni.value}&dataDisponibilizacaoFim=${dataFim.value}`;
    const resp=await fetch(url);
    if(!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const dados=await resp.json();
    processados=processar(dados.items||[]);
    processados.sort((a,b)=>(b.temPrazo?1:0)-(a.temPrazo?1:0));
    filtrados=[...processados];
    if(processados.length===0){stateArea.style.display='flex';stateArea.innerHTML='<div class="state-icon">📭</div><div>Nenhuma intimação encontrada no período.</div>';}
    else{stateArea.style.display='none';popularTribunais();renderLista(filtrados);toolbar.classList.add('vis');filterRow.classList.add('vis');atualizarToolbar();}
  }catch(e){stateArea.style.display='flex';stateArea.innerHTML=`<div class="state-icon">❌</div><div>Erro ao consultar o CNJ.<br><small>${e.message}</small></div>`;}
  finally{btnBuscar.disabled=false;btnBuscar.textContent='Consultar Intimações';}
});
